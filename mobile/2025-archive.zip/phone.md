# Apps

- Lock Screen: https://raw.githubusercontent.com/fru/infrastructure/main/setup/mobile/lockscreen.jpg

## Basics
- Lock Me Out
- Night Shift (Dimm Phone Screen)
- Samsung Mobile Print
- Sunnytimes Widget
- Timely (Homescreen Counter Widget)
- Focusmeter
- Mindfulness Bell

## Office
- Adobe Acrobat
- Google Docs
- Google Sheets
- Google Calendar
- DriveSync

## Outside
- Eversports
- Komoot
- Outdooractive
- PC Caddy
- UVIMate

## Habits
- AnkiPro
- Breathe
- Memorize By Heart
- SpanishDictionary

## Dr
- Doctolib
- SnoreLab
- TeleClinic

## Devices
- Bambu Handy
- Find Hub
- Imou Life
- LIFX
- Nuki
- Tuya Smart
- Wearable
- Withings

## Dev
- ChatGPT
- Expo Go
- Gemini
- Le Chat
- Perplexity
- Replit
- SimpleEditorFree

## Dating
- Badoo
- Bumble
- Tinder

## Data
- Smart Recorder
- Samsung Galery 

## Transport
- DB Navigator
- Google Maps
- mo.pla
- Rheinbahn
- SoFlow

## Listen
- Audible
- CloudBeats
- Listen Audiobook Player
- Pocket Casts
- TIDAL

## Finance
- Consors Bank
- DKB
- Finanzguru
- PayPal
- Wallet

## Work
- Chrome
- Google Drive
- Keep Notes
- Obsidian
- Google Photos
- Raindrop
- Todoist

## Messages
- Google Contacts
- Gmail
- Messages
- Phone
- Signal
- WhatsApp

## Other
- Bitwarden
- Garmin Connect
- Garmin Connect IQ
- Dropbox
- ImmoScout
- ImmoWelt
- MeinMagenta